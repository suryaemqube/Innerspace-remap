/* eslint-disable */
import React, { useState, useEffect, useRef } from "react";
import { Swiper, SwiperSlide } from 'swiper/react';

import { Pagination, Navigation, Parallax, Autoplay } from "swiper/modules";



import gsap from 'gsap';
import ScrollTrigger from "gsap/ScrollTrigger";

import "../assets/css/landing-page-ramadan.css";
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/effect-fade';
import "swiper/css/parallax";




const SwiperIssue = () => {

    const sections = useRef([]);
    const sections2 = useRef([]);

    const [currentIndex1, setCurrentIndex1] = useState(0);
    const [numPanels1, setNumPanels] = useState(null);
    const [swiper1, setSwiper1] = useState(null);
    const [slideCount, setSlideCount] = useState(0);
    const [animating, setAnimating] = useState(null);

    gsap.registerPlugin(ScrollTrigger);
    const sliderRef = useRef();
    const galleryRef = useRef();


    const handleSlideChange = () => {
        setSlideCount(prevCount => prevCount + 1);
        console.log("slideCount", slideCount)
        setCurrentIndex1(prevCount => prevCount + 1)
        console.log("slideCount1", currentIndex1)
    };


    useEffect(() => {

        if (swiper1) {
            let ctx = gsap.context(() => {
                let intentObserver = ScrollTrigger.observe({
                    type: "wheel,touch",
                    onUp: () => {
                        console.log("up", currentIndex1)

                        setCurrentIndex1(currentIndex1=>currentIndex1 + 1)
                        !animating && gotoPanel(currentIndex1, true)
                    },
                    onDown: () => {
                        // setCurrentIndex1(currentIndex1 - 1)
                        console.log("down", currentIndex1)
                        setCurrentIndex1(currentIndex1=>currentIndex1 - 1)
                        !animating && gotoPanel(currentIndex1, false)
                    },
                    wheelSpeed: -1, // to match mobile behavior, invert the wheel speed
                    tolerance: 30,
                    preventDefault: true,
                    onPress: (self) => {
                        ScrollTrigger.isTouch && self.event.preventDefault();
                    }
                });
                intentObserver.disable();

                let preventScroll = ScrollTrigger.observe({
                    preventDefault: true,
                    type: "wheel,scroll",
                    allowClicks: true,
                    onEnable: (self) => {
                        console.log("enable");
                        return (self.savedScroll = self.scrollY());
                    }, // save the scroll position
                    onChangeY: (self) => {
                        console.log("disable");
                        self.scrollY(self.savedScroll); // refuse to scroll
                    }
                });
                preventScroll.disable();


                function gotoPanel(isScrollingDown) {
                    // setCurrentIndex1(index+1)
                    setAnimating(true)
                    console.log("gotoPanel" , currentIndex1, isScrollingDown);
                    // return to normal scroll if we're at the end or back up to the start
                    if (
                        (currentIndex1 === numPanels1 && isScrollingDown) ||
                        (currentIndex1 === -1 && !isScrollingDown)
                    ) {
                        console.log("return to normal scroll");
                        intentObserver.disable();
                        preventScroll.disable();
                        setAnimating(false)
                        preventScroll.scrollY(
                            preventScroll.scrollY() + (currentIndex1 === numPanels1 ? 1 : -1)
                        );
                        return;
                    }
                    swiper1.slideTo(currentIndex1);
                }

                ScrollTrigger.create({
                    trigger: galleryRef.current,
                    pin: true,
                    anticipatePin: true,
                    start: "40% 50%",
                    end: "+=50%",
                    markers: true,
                    onEnter: (self) => {
                        if (preventScroll.isEnabled === false) {
                            self.scroll(self.start);
                            preventScroll.enable();
                            // intentObserver.enable();
                            // gotoPanel(currentIndex1, true);
                            console.log("onEnter", currentIndex1)
                            swiper1.slideTo(currentIndex1);
                        }
                    },
                    onEnterBack: (self) => {
                        if (preventScroll.isEnabled === false) {
                            self.scroll(self.start);
                            preventScroll.enable();
                            // intentObserver.enable();
                            // gotoPanel(currentIndex1, false);
                            console.log("onEnterBack", currentIndex1)
                        }
                    }
                });

                ScrollTrigger.config({
                    ignoreMobileResize: true
                });



                console.log("currentIndex1--", currentIndex1, numPanels1)

            }, sliderRef);

            return () => {
                ctx.revert();
            };
        }

    }, [swiper1, currentIndex1])


    return (
        <>

            <div className="page-template-page-landing-ramadan new-landing-page landing-page more-than-jsut-style choose-the-specialist">
                <div class="brand" style={{ "background": "black", "textlign": "center" }}><a href="https://www.creativecodingclub.com/bundles/creative-coding-club?src=cdp3droll" target="_blank"><img src="https://assets.codepen.io/32887/logo-ill.svg" width="300" alt="" /></a></div>
                <div class="space" style={{ "padding": "20px", "background": "#efefef" }}>
                    <h3>Use mouse wheel to scroll down and navigate Swiper gallery.</h3>
                    <ul style={{ "font-family": "sans-serif" }}>
                        <li>This is a rough proof of concept</li>
                        <li>Not set up to be fully responsive</li>
                        <li>There are intermittent glitches</li>
                        <li>Use at own risk</li>
                        <li><strong style={{ "color": "#600" }}>Zero support is offered for any fixes or updates</strong></li>
                        <li>The community is welcome to hack on this and try to improve it</li>
                    </ul>

                    <h3>Swipe to unlock pining</h3>
                    <p>When the gallery gets pinned be sure to Swipe until the last slide is visible</p>
                    <p>Now you can scroll down to the rest of the page. Neat!</p>

                    <h3>Known Issues</h3>
                    <ul style={{ "font-family": "sans-serif" }}>
                        <li>If you get to slide 6 and scroll all the way down, sometimes on the way up you can bypass the pinning and navigation through the Swiper gallery.</li>
                        <li>Sometimes when going back up the page the pinned Swiper section glitches out. Elements flash and jump a bit. I have no idea what's going on here but I suspect the scroll position is jumping up and down.</li>
                        <li>Attempting to use the Scrollbar while scrolling is disabled results in lots jitters and flasing.</li>
                        <li>After page loads fresh, grab scrollbar and try to scroll down the full page. It becomes a mess when you hit the section that is trying to disable scrolling.</li>

                    </ul>





                </div>

                <section className="hero-banner">



                    <div className="hero-txt">
                        <h1>Choose the Specialist</h1>
                        <p>The  kitchen is the most complex room in the house. <br />That’s why you need a specialist for the job.</p>

                    </div>


                </section>

                <section className="sticky-bg-swrapper">
                    <div className="container">
                        <h2>Why Do I Need a Kitchen Studio?</h2>
                        {typeof window !== "undefined" && window.innerWidth > 767 && (
                            <div className=" banner-sec banner-sec-top" ref={sections}></div>
                        )}
                        <div className="banner-sec-text">
                            <p>No single room in the house can add more value to a home renovation than a well-done kitchen renovation. In recent years, more and more UAE residents have opted to improve the aesthetic, functionality, and value of their home through the addition of customised kitchens.  This can increase home resale value by up to 10% if done to a high standard.</p>
                            <p>While some people opt to build their kitchens with their general contractor, this is not the ideal approach. An experienced general contractor is excellent at carrying out the majority of home renovation and preparing a space for a new kitchen. When it comes to kitchen design, manufacturing and installation, however, there are clear benefits to selecting a German kitchen specialist.
                            </p>
                        </div>
                    </div>
                </section>

                <div class="gallery" ref={galleryRef}>
                    <section className="Benefits " ref={sliderRef}>
                        <div className="swiper-container" style={{ 'height': '130vh' }} id="premium-slider">
                            <Swiper
                                className="swiper"
                                speed={1000}
                                modules={[Navigation, Pagination, Parallax, Autoplay]}
                                direction="vertical"
                                parallax={true}
                                // loop={true}
                                onSwiper={(s) => {
                                    setSwiper1(s);
                                }}

                                onInit={(s)=>{
                                    const numPanels = s.slides.length;
                                    var currentIndex = s.activeIndex;
                                    setCurrentIndex1(currentIndex);
                                    setNumPanels(numPanels + 1);
                                    console.log("onInit", currentIndex)
                                }}  

                                onSlideChange={(swiper) => {
                                    var currentIndex = swiper.activeIndex;
                                    console.log("onSlideC", currentIndex)
                                    handleSlideChange();
                                }}

                                onSlideChangeTransitionEnd={()=>{
                                    setAnimating(false);
                                }}

                            >
                                <SwiperSlide className="swiper-slide">
                                    <div class="left">
                                        <div className="swiper-image" data-swiper-parallax-y="-20%">
                                            <img src="https://app.kaiser.ae/wp-content/uploads/Design-Expertise.jpg" />
                                        </div>
                                        <div className="text-wrap">
                                            <h3>What Our Clients</h3>
                                        </div>
                                    </div>
                                    <div class="right">
                                        <div className="swiper-text" data-swiper-parallax-y="35%">
                                            <div className="paragraph">
                                                <h2>Design Expertise 1</h2>
                                                <p>
                                                    While local joineries design and build kitchens occasionally, a specialised studio creates nothing BUT kitchens day in and day out. That’s what you want when choosing a kitchen brand. A dedicated expert who understands every centimetre of a kitchen, not an occasional supplier who may not be able to foresee potential pitfalls.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </SwiperSlide>
                                <SwiperSlide className="swiper-slide">
                                    <div class="left">
                                        <div className="swiper-image" data-swiper-parallax-y="-20%">
                                            <img src="https://app.kaiser.ae/wp-content/uploads/Design-Expertise.jpg" />
                                        </div>
                                        <div className="text-wrap">
                                            <h3>What Our Clients</h3>
                                        </div>
                                    </div>
                                    <div class="right">
                                        <div className="swiper-text" data-swiper-parallax-y="35%">
                                            <div className="paragraph">
                                                <h2>Design Expertise 2</h2>
                                                <p>
                                                    While local joineries design and build kitchens occasionally, a specialised studio creates nothing BUT kitchens day in and day out. That’s what you want when choosing a kitchen brand. A dedicated expert who understands every centimetre of a kitchen, not an occasional supplier who may not be able to foresee potential pitfalls.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </SwiperSlide>
                                <SwiperSlide className="swiper-slide">
                                    <div class="left">
                                        <div className="swiper-image" data-swiper-parallax-y="-20%">
                                            <img src="https://app.kaiser.ae/wp-content/uploads/Design-Expertise.jpg" />
                                        </div>
                                        <div className="text-wrap">
                                            <h3>What Our Clients</h3>
                                        </div>
                                    </div>
                                    <div class="right">
                                        <div className="swiper-text" data-swiper-parallax-y="35%">
                                            <div className="paragraph">
                                                <h2>Design Expertise 3</h2>
                                                <p>
                                                    While local joineries design and build kitchens occasionally, a specialised studio creates nothing BUT kitchens day in and day out. That’s what you want when choosing a kitchen brand. A dedicated expert who understands every centimetre of a kitchen, not an occasional supplier who may not be able to foresee potential pitfalls.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </SwiperSlide>
                                {/* Add more SwiperSlides as needed */}
                            </Swiper>

                            <div id="currentSlide"
                            //  style="font-size:4vh; font-weight:bold; font-family:sans-serif; width:8em; padding:20px; background:#ccc; border-radius:2.5em; text-align:center; margin:20px auto auto auto"
                            >1</div>
                        </div>
                        <div
                            id="currentSlide"
                            style={{
                                fontSize: "4vh",
                                fontWeight: "bold",
                                fontFamily: "sans-serif",
                                width: "8em",
                                padding: "20px",
                                background: "#ccc",
                                borderRadius: "2.5em",
                                textAlign: "center",
                                margin: "20px auto auto auto",
                            }}
                        >
                            1
                        </div>
                    </section>
                </div>

                <section className="premium">
                    <div className="container">
                        <h2>Explore Our Kitchens</h2>
                    </div>

                    <div className="container">
                        <div className="swiper-container" id="premium-slider">
                            <Swiper
                                modules={[Navigation]}
                                navigation={{
                                    nextEl: ".swiper-button-next",
                                    prevEl: ".swiper-button-prev",
                                }}

                                lazy
                                slidesPerView={3.5}
                                // autoplay={{ delay: 3000 }}
                                // loop={true}
                                spaceBetween={10}
                                breakpoints={{
                                    0: {
                                        slidesPerView: 1.2,
                                    },
                                    600: {
                                        slidesPerView: 2.2,
                                    },
                                    912: {
                                        slidesPerView: 2.5,
                                    },
                                    1280: {
                                        slidesPerView: 3.5,
                                    },
                                    1680: {
                                        slidesPerView: 3.5,
                                    }
                                }}

                            >
                                <div className="swiper-wrapper">
                                    <SwiperSlide>
                                        <div className="premium-title">
                                            <h3>Portfolio Title​​​​</h3>


                                        </div>

                                    </SwiperSlide>
                                </div>


                                <div className="swiper-wrapper">
                                    <SwiperSlide>
                                        <div className="premium-title">
                                            <h3>Portfolio Title​</h3>

                                        </div>

                                    </SwiperSlide>
                                </div>

                                <div className="swiper-wrapper">
                                    <SwiperSlide>
                                        <div className="premium-title">
                                            <h3>Portfolio Title</h3>

                                        </div>

                                    </SwiperSlide>
                                </div>

                                <div className="swiper-wrapper">
                                    <SwiperSlide>
                                        <div class="premium-title">
                                            <h3>Portfolio Title</h3>

                                        </div>

                                    </SwiperSlide>
                                </div>

                                <div className="swiper-wrapper">
                                    <SwiperSlide>
                                        <div class="premium-title">
                                            <h3>Portfolio Title</h3>

                                        </div>

                                    </SwiperSlide>
                                </div>


                            </Swiper>

                        </div>


                        <div id="js-prev1" className="premium-swiper-button-prev swiper-button-prev"></div>
                        <div id="js-next1" className="premium-swiper-button-next swiper-button-next"></div>

                    </div>
                </section>

                <section id="expertSection" className={`expert`}>
                    <div className="container">
                        <h2>Meet Our Expert Design Leaders</h2>
                        <div className="expert-inside">
                            <div className="left">
                                <h3>Book a consultation with our highly experienced design team to <br />create a kitchen that looks beautiful and works beautifully for</h3>


                            </div>
                            <div className="right" id="getInToch">
                                <div class="form-wrap">
                                    <h3>Start Your Kitchen Journey</h3>


                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="banner-sec-footer footer-banner" ref={sections2}>


                    {/* </div> */}
                    <div className="container bottom-sec">
                        <h2>A Kitchen is an Investment.<br /> Invest in More than Just Style.</h2>
                    </div>
                </section>


                <footer>

                    <div className="container contain">

                        <div className="col1">



                        </div>



                        <div className="col2">


                            <div className="footer-top-wrapper">

                                <div className="footer-links">

                                    <h5>Visit Our Showroom</h5>
                                    <p>Kaiser Kitchen Showroom, <br />
                                        API Business Suites, Al Barsha 1<br />
                                        Dubai, UAE</p>
                                    <p>
                                        <a
                                            className="get-directions"
                                            href="https://goo.gl/maps/Egwo6RpQsDDWFfvP7"
                                            target="_blank"
                                        ><svg
                                            xmlns="http://www.w3.org/2000/svg"
                                            width="20.25"
                                            height="29.25"
                                            viewBox="0 0 20.25 29.25"
                                        >
                                                <path
                                                    id="Icon_ionic-ios-pin"
                                                    data-name="Icon ionic-ios-pin"
                                                    d="M18,3.375c-5.59,0-10.125,4.212-10.125,9.4C7.875,20.088,18,32.625,18,32.625S28.125,20.088,28.125,12.776C28.125,7.587,23.59,3.375,18,3.375ZM18,16.8a3.3,3.3,0,1,1,3.3-3.3A3.3,3.3,0,0,1,18,16.8Z"
                                                    transform="translate(-7.875 -3.375)"
                                                    fill="#ffc500"
                                                ></path></svg> Get Directions</a
                                        >
                                    </p>
                                </div>
                            </div>

                        </div>


                        <div className="col3">
                            <div className="contact-us">
                                <h5>Speak to Our Designers</h5>
                                <p>
                                    <a className="email" href="mailto:hello@innerspacedxb.com">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="16.201" viewBox="0 0 24 16.201">
                                            <path id="Icon_zocial-email" data-name="Icon zocial-email"
                                                d="M.072,18.834V5.5q0-.023.069-.44l7.846,6.712L.165,19.3a1.961,1.961,0,0,1-.093-.463Zm1.041-14.7a1,1,0,0,1,.393-.069h21.13a1.311,1.311,0,0,1,.417.069l-7.869,6.735-1.041.833-2.06,1.689-2.06-1.689-1.041-.833ZM1.137,20.2l7.892-7.568,3.055,2.476,3.055-2.476L23.031,20.2a1.111,1.111,0,0,1-.393.069H1.507a1.048,1.048,0,0,1-.37-.069ZM16.18,11.775,24,5.063a1.381,1.381,0,0,1,.069.44V18.834A1.774,1.774,0,0,1,24,19.3Z"
                                                transform="translate(-0.072 -4.068)" fill="#ffc500"></path>
                                        </svg>
                                        hello@innerspacedxb.com</a>
                                    <a className="tel" href="tel:+971042526500"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        viewBox="0 0 24 24">
                                        <path id="Icon_awesome-phone-alt" data-name="Icon awesome-phone-alt"
                                            d="M23.315,16.96l-5.25-2.25a1.125,1.125,0,0,0-1.313.323l-2.325,2.841A17.375,17.375,0,0,1,6.122,9.568L8.963,7.243A1.122,1.122,0,0,0,9.286,5.93L7.036.68A1.133,1.133,0,0,0,5.747.029L.872,1.154A1.125,1.125,0,0,0,0,2.25,21.748,21.748,0,0,0,21.75,24a1.125,1.125,0,0,0,1.1-.872l1.125-4.875a1.139,1.139,0,0,0-.657-1.294Z"
                                            transform="translate(0 0)" fill="#ffc500"></path>
                                    </svg>+971 (0) 4 252 6500</a>
                                </p>
                            </div>


                            <div className="social-icon">
                                <ul>
                                    <li>
                                        <a href="https://www.linkedin.com/showcase/kaiser-kitchens-dubai" target="_blank">
                                            <img src="https://app.kaiser.ae/wp-content/uploads/icon-linked-in-1.svg" width="35" height="35" alt="LinkedIn" />
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.facebook.com/KaiserKitchensDubai/" target="_blank">
                                            <img src="https://app.kaiser.ae/wp-content/uploads/icon-facebook-1.svg" width="35" height="35" alt="Facebook" />
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/kaiserkitchensdubai/" target="_blank">
                                            <img src="https://app.kaiser.ae/wp-content/uploads/icon-instagram-1.svg" width="35" height="35" alt="Instagram" />
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://wa.me/971521384518?text=Hi" target="_blank">
                                            <img src="https://app.kaiser.ae/wp-content/uploads/whats-app-icon.svg" width="35" height="35" alt="Instagram" />
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>


                    <div className="container contain credits-copy">

                        <div className="credits">Copyright&copy;. Innerspace Trading LLC</div>

                    </div>

                </footer>

                <div className="stick-wp-wrapper sticky-whatsapp">
                    <div id="sticky-call" class="sticyk-whatsapp menu-item menu-item-type-post_type menu-item-object-page menu-item-76">
                        <a href="https://wa.me/971521384518?text=Hi" class="visit-btn" target="_blank">

                            <span class="icon-wrapp">

                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24.031" viewBox="0 0 24 24.031">
                                    <path id="Icon_zocial-call" data-name="Icon zocial-call" d="M3.318,7.662a1.768,1.768,0,0,1,.45-.96l3.6-3.6q.421-.36.63.12l2.91,5.461a.786.786,0,0,1-.15.93l-1.32,1.32a1.493,1.493,0,0,0-.42.93,4.58,4.58,0,0,0,.93,2.31,19.73,19.73,0,0,0,1.83,2.4l.93.959c.28.28.639.625,1.081,1.035a18.114,18.114,0,0,0,2.174,1.62,4.867,4.867,0,0,0,2.385,1.005,1.306,1.306,0,0,0,.96-.39l1.561-1.56a.659.659,0,0,1,.9-.12l5.252,3.09a.438.438,0,0,1,.24.315.383.383,0,0,1-.12.345l-3.6,3.6a1.763,1.763,0,0,1-.959.449,7.259,7.259,0,0,1-3.316-.405,15,15,0,0,1-3.42-1.635q-1.575-1.02-2.925-2.069t-2.16-1.8l-.78-.751q-.3-.3-.8-.825T7.458,17.368a30.134,30.134,0,0,1-2.13-3.015,17.591,17.591,0,0,1-1.56-3.346A7.117,7.117,0,0,1,3.318,7.662Z" transform="translate(-3.267 -2.947)" />
                                </svg>



                            </span>



                        </a>
                    </div>
                    <div id="sticky-wp" class="sticyk-whatsapp menu-item menu-item-type-post_type menu-item-object-page menu-item-76">
                        <a href="https://wa.me/971521384518?text=Hi" class="visit-btn" target="_blank">
                            <span class="icon-wrapp">
                                <svg xmlns="http://www.w3.org/2000/svg" width="27.75" height="27.75" viewBox="0 0 27.75 27.75">
                                    <path id="Icon_ionic-logo-whatsapp" data-name="Icon ionic-logo-whatsapp" d="M16.377,2.25A13.571,13.571,0,0,0,2.754,15.768a13.378,13.378,0,0,0,1.955,6.98L2.25,30l7.542-2.4A13.646,13.646,0,0,0,30,15.768,13.57,13.57,0,0,0,16.377,2.25ZM23.151,20.9a3.519,3.519,0,0,1-2.409,1.553c-.639.034-.657.5-4.14-1.018s-5.578-5.193-5.743-5.43a6.681,6.681,0,0,1-1.285-3.621A3.86,3.86,0,0,1,10.9,9.553a1.334,1.334,0,0,1,.943-.4c.274,0,.452-.008.655,0s.507-.042.771.659.895,2.425.975,2.6a.631.631,0,0,1,.006.605,2.366,2.366,0,0,1-.369.563c-.182.195-.382.436-.545.585-.181.165-.37.345-.18.7A10.425,10.425,0,0,0,15,17.327a9.5,9.5,0,0,0,2.732,1.816c.342.186.545.165.757-.058s.907-.975,1.152-1.311.475-.271.789-.144,1.992,1.026,2.334,1.211.569.281.651.427A2.861,2.861,0,0,1,23.151,20.9Z" transform="translate(-2.25 -2.25)" fill="#25d366" />
                                </svg>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </>
    )
}

export default SwiperIssue;